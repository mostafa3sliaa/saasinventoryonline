const { Client } = require('pg');
const fs = require('fs');

async function run() {
  const client = new Client({
    connectionString: 'postgresql://postgres:0bDI8XtD8P0h6C6D@db.xfvmetvwyzvccumftekp.supabase.co:5432/postgres',
    ssl: { rejectUnauthorized: false }
  });
  
  try {
    await client.connect();
    console.log("Connected to Supabase Postgres.");
    
    // Split statements or run as a single block depending on file structure.
    // pg driver can execute multiple statements in one query if they are separated by semicolons.
    const schema = fs.readFileSync('supabase/schema.sql', 'utf8');
    console.log("Running schema.sql...");
    await client.query(schema);
    console.log("schema.sql executed successfully.");
    
    const activation = fs.readFileSync('supabase/apply_activation_migration.sql', 'utf8');
    console.log("Running apply_activation_migration.sql...");
    await client.query(activation);
    console.log("apply_activation_migration.sql executed successfully.");
    
  } catch (err) {
    console.error("Migration failed:", err);
  } finally {
    await client.end();
  }
}

run().catch(console.error);
