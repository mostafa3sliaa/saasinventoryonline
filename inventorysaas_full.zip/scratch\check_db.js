const { createClient } = require('@supabase/supabase-js');

const supabase = createClient(
  'https://xfvmetvwyzvccumftekp.supabase.co',
  'sb_publishable_diyaPjDmMXu64kmY5YgH7g_Gm6taVpg'
);

async function check() {
  console.log("Checking database connection and tables...");
  const { data, error } = await supabase.from('tenants').select('*').limit(1);
  if (error) {
    console.error("Error details:", error.message);
    process.exit(1);
  } else {
    console.log("SUCCESS! Database is linked and tables exist.");
    console.log("Data:", data);
  }
}
check();
